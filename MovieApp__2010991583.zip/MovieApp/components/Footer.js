function Footer() {
	return (
		<div className="text-center h-32 flex items-center justify-center">
			<p className="text-xl text-gray-800 dark:text-white  font-display">
				&copy; 2023 <span className="font-bold">CHITKARA</span>
			</p>
		</div>
	);
}

export default Footer;
